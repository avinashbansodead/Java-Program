class Method_Formal_Actual_Argu
{
	public static void main(String[] args) {
		int a=10;
		int b=20;
		int sum=m1(a,b);
System.out.println(sum);

	}

	public static int m1(int a,int b)
		{
			int sum=a+b;
			m2();
			return sum;
			
			
		}
public static void m2()
{
System.out.println("Hello");
}
}