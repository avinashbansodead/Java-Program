class Pattern1
{
	public static void main(String[] args)
	{
	
	for(char ch='A';ch<='Z';ch++)
	{
		System.out.println(ch);
		
	}
	}
}


		
	

