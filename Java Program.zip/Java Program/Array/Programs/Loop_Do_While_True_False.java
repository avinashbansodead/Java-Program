class Loop_Do_While_True_False
{
	public static void main(String[] args) {
			
		do
		{
			System.out.println("Hii");
			

		}
		while(false);
		System.out.println("byee");
		System.out.println("Hello");


	}
}