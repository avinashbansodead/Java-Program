import java.util.Scanner;
class Scanner_Char
{
	public static void main(String[] args) {
		
	
Scanner sc=new Scanner(System.in);
System.out.println("Enter the Character");
 char ch=sc.next().charAt(0);
ch=ch+10;

System.out.println(ch);


}
}
