class Array_Dimension
{
	public static void main(String[] args) {
		int[][]a=new int[10][];
	}
}