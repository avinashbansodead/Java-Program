class To_StringMethod
{
	String a;
	int i;
	To_StringMethod(String a,int i)
	{
		this.a=a;
		this.i=i;
	}
	public static void main(String[] args) {
		To_StringMethod t1=new To_StringMethod("Raju",1);
		To_StringMethod t2=new To_StringMethod("Sham",2);
		To_StringMethod t3=new To_StringMethod("Ram",3);
System.out.println(t1.hashCode());
System.out.println(t2.hashCode());
System.out.println(t3.hashCode);
	}
	public int hashCode()
	{
		return i;
	}
}