class Switch_Case_Boolean
{
	public static void main(String[] args) {
		boolean a=true;
		
		switch(1)
		{
			case true:System.out.println("Hii");
			break;
			case 1:System.out.println("Hello");
			break;
			default:System.out.println("Byee");
			
		}
	}
}