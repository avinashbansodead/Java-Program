class Switch_Case_Byte
{
	public static void main(String[] args) {
		byte a=10;
		switch(a)
		{
			case 9:System.out.println("Hii");
			break;
			case 10:System.out.println("Hello");
			break;
			default:System.out.println("Byee");
			
		}
	}
}