class String_DobuleEqual
{
	public static void main(String[] args) {
		String a=new String("Hello");
		String b=new String("Hello");
		String c="Hello";
		System.out.println(a==c);
	}
}