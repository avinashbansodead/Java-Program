class String_Immutable
{
	public static void main(String[] args) {
		String a="Hello";
		a=a.concat("byee");
		System.out.println(a);
		StringBuffer b=new StringBuffer("go");
		System.out.println(b);
		StringBuffer q=b.append("anywhere");
		System.out.println(b);
		System.out.println(q);
	}
}