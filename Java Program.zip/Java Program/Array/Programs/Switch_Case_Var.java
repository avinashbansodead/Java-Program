class Switch_Case_Var
{
	public static void main(String[] args) {
		int a=10;
		int b=20;
		switch(a)
		{
			case 9+1:System.out.println("Hii");
			break;
			case b:System.out.println("Hello");
			break;
			default:System.out.println("Byee");
			
		}
	}
}