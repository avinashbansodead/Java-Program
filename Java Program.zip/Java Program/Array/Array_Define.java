class Array_Define
{
	public static void main(String[] args) {
		int[]a,b;
		int c[],d;
	}
}