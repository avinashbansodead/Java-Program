class Special_Character
{
	public static void main(String[] args) {
		for(byte i=10;i<11;i++)
		{
			System.out.println(i);
		}
char a='?';
int b=a

		System.out.println();

	}
}