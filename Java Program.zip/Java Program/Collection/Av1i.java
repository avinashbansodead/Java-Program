
class Av1i
{
    public static void main(String[] args)
  {
List l=new ArrayList();
l.add(10);
l.add(20);
l.add(30);
l.add(40);
l.add("Hii");
l.add("Hello");
l.add("vishal");
l.add("w");
int s=0;
while(s<l.size())
{
	System.out.println(l.get(s++));
  }
}

}