interface Interface_Example
{
	public static void main(String[] args) {
		m1();

	}
	public static void m1()
	{
		System.out.println("Hello");
	}
}