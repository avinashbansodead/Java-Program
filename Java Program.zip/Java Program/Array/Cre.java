class Cre
{
	public static void main(String[] args)
	 {
	 	int []a=new int[2];
	 	a[0]=10;
	 	a[1]=20;
	 	System.out.println(a[0]);
	 	System.out.println(a[1]);
	 	int[]b={10,20};
		b[0]=50;
		System.out.println(b[0]);
		System.out.println(b[1]);
	}
}