class NDatatype
{
	public static void main(String[] args) {
		
	}
}