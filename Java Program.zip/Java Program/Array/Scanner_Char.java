import java.util.Scanner;
class Scanner_Char
{
	//final char e='a';
	public static void main(String[] args) {
		//Scanner_Char x=new Scanner_Char();
		//char j=x.e+4;
		//System.out.println(j);
		Scanner sc=new Scanner(System.in);
System.out.println("Enter the name");
		char a=sc.next().charAt(0);
		//int a=a-32;
		
		System.out.println(a);
		final char c='b'+1;
	   char d=c+1;
		System.out.println(d);
String name="Vishnu";
		char p=name.charAt(1);
		p+=32;
		
		System.out.println(p);
	}
}