import java.util.Scanner;
class Fibonacci
{
	 public static void main(String[] args) 
	 {
	 Scanner sc=new Scanner(System.in);
	 System.out.println("Enter the Number");
	 int num=sc.nextInt();
	 //
	 int n1=0,n2=1;
	 int n3=0;
	 System.out.print(n1+" "+n2+" ");
	 //int i=3;
	 while(n3<
	 	num)
	 {
	 	n3=n1+n2;
	 	System.out.print(n3+ " ");
	 	n1=n2;
	 	n2=n3;
	 	


	 }
	 if (n3==num)
	 {
	 	System.out.println();
	 	System.out.println("Number belong to fibonacci");
	 }
	 else
	 	{
	 		System.out.println("Number doesn't belong to fibonacci");
	 	}



	}

}