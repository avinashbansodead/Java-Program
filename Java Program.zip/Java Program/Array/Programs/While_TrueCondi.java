class While_TrueCondi
{
	public static void main(String[] args) {
		
		
		while(false)
		{
			System.out.println("Hii");
	
		
		}
System.out.println("Hello");
		
		
	}
}