class String_Comparision
{
	public static void main(String[] args) {
		String a="Hello";
		String b="byee";
		String c=a+b;
		String d="Sorrry";
		System.out.println(c=="Hellobyee");
		System.out.println(d=="Sorrry");
		System.out.println(a=="Hello");
		
	}
}