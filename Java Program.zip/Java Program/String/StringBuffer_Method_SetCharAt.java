class StringBuffer_Method_SetCharAt
{
	public static void main(String[] args) {
		StringBuffer sb=new StringBuffer("hello");
		sb.setCharAt(0,'H');
		System.out.println(sb);
	}
}