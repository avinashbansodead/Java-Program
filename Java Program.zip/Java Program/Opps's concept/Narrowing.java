class Narrowing
{
	public static void main(String[] args) {
		
		short b=257;
byte c=(byte)b;
System.out.println(c);
byte a=127;

System.out.println(a);
int d=a;

System.out.println(d);

	}
}