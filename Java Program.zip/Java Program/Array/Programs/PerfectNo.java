import java.util.Scanner;
class PerfectNo
{
	public static void main(String[]args)
	{
	Scanner sc=new Scanner(System.in);
	System.out.print("Enter the Number");
	int a=sc.nextInt();
		int sum=0;
	for(int i=1;i<a;i++)
	{
		if(a%i==0)
		{
			sum=sum+i;
		}
	}
	if(sum==a)
	{
		System.out.println("It is Perfect Number");

	}
	else
	{
		System.out.println("It is not Perfect Number");
	}
}}