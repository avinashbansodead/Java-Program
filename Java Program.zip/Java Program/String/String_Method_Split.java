import java.util.*;
class String_Method_Split
{
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter your name");
		String a=sc.nextLine();
		
		String []b=a.split("a");
		System.out.println(Arrays.toString(b));

	}
}