import java.util.Scanner;
class Cylinder_Area_Volume
{
public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter the radius and height of the cyclinder");
	float rad=sc.nextFloat();
	float heig=sc.nextFloat();
	double pi=3.14;
	double area=pi*rad*rad;
	double volume=area*heig;
	System.out.println("The area of cylinder is:"+area);
	System.out.println("The volume of cylinder is:"+volume);
}
}