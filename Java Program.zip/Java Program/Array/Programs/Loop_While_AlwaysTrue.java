class Loop_While_AlwaysTrue
{
	public static void main(String[] args) {
		while(false);
		System.out.println("hello");
	}
}