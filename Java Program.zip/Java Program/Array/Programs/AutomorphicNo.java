import java.util.Scanner;
class AutomorphicNo
{
	public static void main(String[]args)
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the Number");
		int num=sc.nextInt();
		int temp=num;
		int sq=num*num;
		int d=1;
		while(num!=0) 
		{
			d=d*10;
			num/=10;
			
		}
		if(sq%d==temp)
		{
			System.out.println("It is an Automorphic Number");

		}
			else
		{
				System.out.println("It is not an Automorphic Number");

		}
	
	}
}