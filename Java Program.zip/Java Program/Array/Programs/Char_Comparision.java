class Char_Comparision
{
	public static void main(String[] args) {
		
	
	char a='A';
	char b=65;
	System.out.printlnj(a==b);
}
}