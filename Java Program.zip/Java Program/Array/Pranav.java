class Pranav
{
	public static void main(String[] args) throws InterruptedException
		{
			Thread.sleep(3000);
			System.out.print("P");
			Thread.sleep(3000);
			System.out.print("R");
			Thread.sleep(3000);
			System.out.print("A");
			Thread.sleep(3000);
			System.out.print("N");
			Thread.sleep(3000);

			System.out.print("A");
			Thread.sleep(3000);
			System.out.print("V");
			Thread.sleep(3000);

			System.out.print("  ");

			System.out.print("N");
			Thread.sleep(3000);
			System.out.print("I");
			System.out.print("K");
			Thread.sleep(3000);
			System.out.print("A");
			Thread.sleep(3000);
			System.out.print("M");


		}
	}
