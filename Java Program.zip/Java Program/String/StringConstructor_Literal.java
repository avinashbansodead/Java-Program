class StringConstructor_Literal
{
	public static void main(String[] args) {
		String a=new String("Welcome to java");
		System.out.println(a);
	}
}