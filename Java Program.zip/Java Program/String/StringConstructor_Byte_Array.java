class StringConstructor_Byte_Array
{
	public static void main(String[] args) {
		byte[]a={97,98,99};
		String a1=a.toString();
		String b=new String(a);
		System.out.println(b);
		//System.out.println(a==b);
		System.out.println(a1==b);
	}
}