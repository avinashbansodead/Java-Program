class Char_Default_Value	
{
	static String a;
	
	public static void main(String[] args) {
	System.out.println("Hii");

		System.out.println(a);
		System.out.println("Helllo");
	}
	}