import java.util.*;
class CharArray_EvenOddAscii
{
	public static void main(String[] args) {
		String name="ABCD";
		char[]a=new char[name.length()];
		
		for(int i=0;i<name.length();i++)
		{
			
			a[i]=name.charAt(i);

			if (a[i]%2==0)
			{
				System.out.println(a[i]+" is a even ascii value");
			}
			else
				System.out.println(a[i]+" is a odd ascii value");
		}
		
	}
}