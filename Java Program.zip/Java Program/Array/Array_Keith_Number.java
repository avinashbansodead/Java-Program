import java.util.*;

class Array_Keith_Number
{

public static void main(String[]args)
	{
Scanner sc=new Scanner(System.in);
System.out.print("Enter the Number");
int num=sc.nextInt();

int length=0;
int temp=num;
int temp1=temp;

while(num!=0)
{
	length++;
	num/=10;

}
int count=0;


		
				int a[]=new int[(length)];

	while(temp!=0)
	{
		int rem=temp%10;
		a[count]=rem;

		temp/=10;
		count++;
		
		}
		if (length==2)
{
	
	
	int add=0;


	int first=a[1];

	int second=a[0];

	
		while(add<temp1)

	{
	add=first+second;
	
	first=second;
	
	second=add;

}

	if(add==temp1)
	{
		System.out.println(temp1+" is a keith number");
	}
	else 
	{
		System.out.println(temp1+" is not a keith number");
	}
	


}





	
else if(length==3)
{
	int add=0;
	int first=a[2];
	int second=a[1];
	int third=a[0];
	while(add<temp1)
	{
		add=first+second+third;
		first=second;
		second=third;
		third=add;

	}
		if(add==temp1)
		{
			System.out.println(temp1+" is a keith number");

		}
		else
       {
	System.out.println(temp1+"It is not a keith number");
	
       }
		

	

}


		
		
}
}


	
