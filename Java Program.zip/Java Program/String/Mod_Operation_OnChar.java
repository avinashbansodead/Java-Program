class Mod_Operation_OnChar
{
	public static void main(String[] args) {
		char a='d'/2;
		int b=a;
		System.out.println(b);
	}
}