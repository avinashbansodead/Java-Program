class Default_ConstructorO_Call
{
	int a=20;
	{
		System.out.println(a);
	}
}