import java.util.*;
class Arrays_ToStringMethod
{


public static void main(String[] args) {
	
	int[][]a={{10,20,30},{30,40,50}};
	System.out.println(Arrays.toString(a[1]));
}
}