class Vrushab
{
	public static void main(String[] args) throws InterruptedException
		{
			Thread.sleep(3000);
			System.out.print("V");
			Thread.sleep(3000);
			System.out.print("R");
			Thread.sleep(3000);
			System.out.print("U");
			Thread.sleep(3000);
			System.out.print("S");
			Thread.sleep(3000);

			System.out.print("H");
			Thread.sleep(3000);
			System.out.print("A");
			Thread.sleep(3000);
			System.out.print("B");
			Thread.sleep(3000);
			System.out.print("H");

		}
	}
