class String_Buffer_Append
{
	public static void main(String[] args) {
	String b=m1("1234-5678-4321-87654");
	System.out.println(b);

	}
	public static String m1(String a)
	{
		String x="xxxx-xxxx-xxxx";
		StringBuffer sb=new StringBuffer(a);
		sb.substring(15,19);
		System.out.println(sb);
		String c=sb.toString();

		System.out.println(a.equals(c));
		return x+sb;
	}
}