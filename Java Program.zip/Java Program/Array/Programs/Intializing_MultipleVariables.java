class Intializing_MultipleVariables
{
	public static void main(String[] args) {
		
		int a=10,b=20,c=30;
		a=40;b=50;c=60;
		System.out.println(a);
		System.out.println(b);
		System.out.println(c);
	}
}