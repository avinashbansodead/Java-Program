class NonStatic_Char
{
	final char a='a';
	public static void main(String[] args) {
		NonStatic_Char b=new NonStatic_Char();
		int c=b.a+1;
		System.out.println(c);
	}
}