import java.util.Scanner;
class Difference1
{
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the name");
		char name=sc.nextLine().charAt();
		//String name=sc.nextLine();
		System.out.println(name);
	}
}