import java.util.Scanner;
class Lenght_Of_Number_ForLoop
{
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the number");
		long num=sc.nextLong();
		int count=0;
		for(int i=0;num!=0;)
		{
			num/=10;
			++count;
		}
		System.out.println(count);
	}
}