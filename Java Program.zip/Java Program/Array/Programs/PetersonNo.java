import java.util.Scanner;
class PetersonNo
{
	public static void main(String[]args)

{
	Scanner sc=new Scanner(System.in);
	System.out.print("Enter the Number");
int num=sc.nextInt();
int temp=num;
int sum=0;
//System.out.println(sum);
while(num!=0)
{
	
	int rem=num%10;
	int fact=1;
	//System.out.println(fact);
	for(int i=rem;i>0;i--)
	{
		fact=fact*i;
	}
	sum=sum+fact;
	num/=10	;
System.out.println(sum);
}

System.out.print(temp==sum?"It is Peterson Number":"It is not Peterson Number");
		}}