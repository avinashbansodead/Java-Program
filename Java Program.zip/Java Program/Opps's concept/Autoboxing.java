class Autoboxing
{
	public static void main(String[] args) {
		Character A=100;
		

		
		A++;
		System.out.println(A);
		
	}
}