class Loop_For_ContitionalStat
{
	public static void main(String[] args) {
		final int a=10;
		 final int b=20;
		for(int i=0; a>b;++i)
		{
			System.out.print("Hii "+i);

		}
		System.out.println("Byee");
		
		
	}
}