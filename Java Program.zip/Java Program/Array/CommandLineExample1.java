import java.util.*;
class CommandLineExample1
{
	public static void main(String[] args) {
	System.out.println(args.length);
	}
}