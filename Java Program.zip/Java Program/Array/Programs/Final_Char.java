class Final_Char
{
	public static void main(String[] args) {
		final char c='a';
		char d=c+1;
		System.out.println(d);
	}
}		