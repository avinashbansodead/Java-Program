class EmptyPrintStatement
{
	public static void main(String[] args) {
		int a=10;
	}
}