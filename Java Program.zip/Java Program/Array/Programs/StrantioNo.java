import java.util.Scanner;
class StrantioNo
{
	public static void main(String[]args)
	{
		Scanner sc=new Scanner(System.in);
		System.out.print("Enter the number");
		int num=sc.nextInt();
		int temp=num;
		if(num>999&&num<10000)
		{
			
			num=num*2;
			num=num/10;
			num=num%100;
			if((num%10)==(num/10))
		
	    {
				System.out.print( temp+" is Strantio Number");
	    }
         else
         {
         	System.out.print(temp+" is not Strantio Number");

         }
     }

	}
}