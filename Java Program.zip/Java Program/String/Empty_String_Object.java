class Empty_String_Object
{
	static String s2;
	public static void main(String[] args) {
		String s=new String();
		String s1=" ";
		String s3="";

		System.out.println(s);
	    System.out.println(s1);
	    System.out.println(s2);
	    System.out.println(s3);

	}
}