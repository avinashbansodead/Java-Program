import java.util.*;
class Inbuilt_ClassName
{
public static void main(String[] args) 
{
	byte[]a=new byte[2];
	System.out.println(a.getClass());

	short[]b=new short[2];
	System.out.println(b.getClass().getName());

	int[]c=new int[2];
	System.out.println(c.getClass());

	long[]d=new long[2];
	System.out.println(d.getClass());

	double[]e=new double[2];
	System.out.println(e.getClass());

	float[]f=new float[2];
	System.out.println(f.getClass());

	char[]g=new char[2];
	System.out.println(g.getClass());

	String[]h=new String[2];
	System.out.println(h.getClass());

	boolean[]i=new boolean[2];
	System.out.println(i.getClass());
}
}
