abstract class Abstract_Example
{
	public static void main(String[] args) {
		m1();

	}
	public static void m1()
	{
		System.out.println("Hello");
	}
	default static void m()
	{
		System.out.println("Hello");
	}
}