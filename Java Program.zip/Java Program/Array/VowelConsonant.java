class VowelConsonant
{
	public static void main(String[] args) 
	{
		char[]a={'a','b','c','d','e','f','g','h','i','j','k','l','m','n'};
		for(int j=0;j<a.length;j++)
		{
			if(a[j]=='a'||a[j]=='e'||a[j]=='o'|| a[j]=='i'||a[j]=='u')
			{                                                                                                                    
				System.out.println(a[j]+":is a vowel");
			}
			else
			{
				System.out.println(a[j]+":is a ++Consonant");
			}
		}
	}
}