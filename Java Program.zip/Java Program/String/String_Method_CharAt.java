class String_Method_CharAt
{
	public static void main(String[] args) {
		String b="Hello";
		int a=b.charAt(2);
		System.out.println(a);
	}
	public static char charAt(int x) 
	{
		System.out.println(x);
		return '9';
	}
}