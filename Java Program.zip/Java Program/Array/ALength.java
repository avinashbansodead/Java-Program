class ALength
{
	public static void main(String[] args) 
		{
		int[]a={10,20,30,40,50};
		System.out.println(a.length);
		}
	}
