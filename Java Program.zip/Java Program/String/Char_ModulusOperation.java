class Char_ModulusOperation
{
	public static void main(String[] args) {
		char a='b'/2;
		
		System.out.println(a);

	}
}