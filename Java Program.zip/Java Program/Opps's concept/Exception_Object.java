class Exception_Object
{
	public static void main(String[] args) {
		throw new ArithmeticException();
	}
}