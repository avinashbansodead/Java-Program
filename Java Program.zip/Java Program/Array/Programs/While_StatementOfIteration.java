class While_StatementOfIteration
{
	public static void main(String[] args) {
		int i=1;
		while(i!=10)

		{
			i++;
System.out.println(i);
		}
		
	}
}