class Method_Calling
{
	public static void main(String[] args) {
		m1(10);
	}
	public static void m1(int a) 
	{
	System.out.println(a);	
	}
	public static void m1(int b) 
	{
	System.out.println(b);	
	}
}