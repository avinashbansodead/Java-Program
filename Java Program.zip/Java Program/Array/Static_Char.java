class Static_Char
{
static final char a='a';
public static void main(String[] args) {
	char b=a+1;
	System.out.println(b);
}
}