class This_KeywordUse
{
	int a=20;
	public static void main(String[] args) {
		This_KeywordUse b=new This_KeywordUse();
		b.m1();
	}
	public void m1()
	{
		int a=30;
		System.out.println(a);
		System.out.println(this.a);
	}
}