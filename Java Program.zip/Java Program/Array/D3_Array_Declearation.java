import java.util.*;
class D3_Array_Declearation
{


public static void main(String[] args) 
{
	int [][][]a={{{10},{20,30}},{{40,50}},{{60,70},{80}}};
	a[0][0][0]=100;
	System.out.println(a[0][0][0]);
	System.out.println(a[0][1][0]);
	System.out.println(a[0][1][1]);
	System.out.println(a[1][0][0]);
	System.out.println(a[1][0][1]);
	System.out.println(a[2][0][0]);
	System.out.println(a[2][0][1]);
	System.out.println(a[2][1][0]);
}
	}