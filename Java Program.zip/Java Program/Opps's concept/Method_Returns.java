import java.util.*;
class Method_Returns
{
	public static void main(String[] args) {
		Method_Returns a=new Method_Returns();

		Method_Returns b=a.m1().m2();
		System.out.println(b.toString());
	}
	public Method_Returns m1()
	{
		System.out.println("Hello");
		return this;
	}
	public Method_Returns m2()
	{
		System.out.println("Byee");
		return this;
	}
}