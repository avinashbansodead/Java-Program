class Electronics 
{
	String type;
	String brand;
	String price;

Electronics(String type,String brand,String price)
}
this.type=type;
this.brand=brand;
this.price=price;