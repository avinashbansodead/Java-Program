class Method_With_Formal_Not_Return
{
	public static void main(String[] args) {
		m1(10);

	}
	public static void m1(int a)
	 {
		System.out.println(a);
	}
}