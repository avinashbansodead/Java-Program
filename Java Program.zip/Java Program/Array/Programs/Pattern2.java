class Pattern2
{
	public static void main(String[] args)
	{
	
	for(char ch='A';ch<='Z';ch++)
	{
		System.out.println(ch+"="+ (ch+0));
		
	}
	}
}


		
	

