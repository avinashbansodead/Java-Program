class Datatype_Range_Cross
{
	public static void main(String[] args) {
		int a=2147483647;
		System.out.println(++a);
	}
}