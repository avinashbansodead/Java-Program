import java.util.*;
class Party
{
 public static void main(String[] args) 
	{
		int[]b={10,20,30};
		System.out.println(Arrays.toString(b));
	}
}