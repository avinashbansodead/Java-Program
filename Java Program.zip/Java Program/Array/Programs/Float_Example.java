class Float_Example
{
	public static void main(String[] args) {
		float a=10.0f/3;
		System.out.println(a);
	}
}