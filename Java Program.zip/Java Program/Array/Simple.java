class Simple
{
	public static void main(String[] args) {
		String b="a";
		String a="int ";
		String c=a+b;
		
		String e=c+"="+20;
		System.out.println(e);
 a=e;
	}
}