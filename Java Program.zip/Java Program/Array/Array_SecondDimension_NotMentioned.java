import java.util.*;
class Array_SecondDimension_NotMentioned
{
	public static void main(String[] args) {
		int[][]a=new int[3][];
		//a[0]=new int[2];
		a[0]=new int[1];
		
		



		System.out.println(Arrays.toString(a[0]));
	}
}