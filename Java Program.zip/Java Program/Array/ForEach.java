class ForEach
{
	public static void main(String[] args)
	 {
	 	int[]a={10,20,30};
	 	for(int i:a)
	 	{
	 		System.out.print(i+" ");
	 	}
		
	}
}