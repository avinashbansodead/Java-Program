class String_Buffer_Constructor
{
public static void main(String[] args) {
	StringBuffer a=new StringBuffer("hi");
	a.append("abcdefghijklmnopqrstu123456789qwert");
	System.out.println(a.length());
	System.out.println(a.capacity());
}}