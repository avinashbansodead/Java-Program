class Non_Static_Variable_Accessibility

{
	int a=20;
	public static void main(String[] args) {
		Non_Static_Variable_Accessibility b=new Non_Static_Variable_Accessibility();
		System.out.println(b.a);
	}
}