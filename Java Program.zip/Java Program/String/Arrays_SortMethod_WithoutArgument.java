import java.util.Arrays;
  
class Arrays_SortMethod_WithoutArgument
 {
    public static void main(String args[])
    {
        int[] a = { 5, -2, 23, 7, 87, -42, 509 };
        Arrays.sort(a);
         System.out.println(Arrays.toString(a));

        char[]b={'a','c','d','k','a'};
        Arrays.sort(b);
        System.out.println(Arrays.toString(b));

        char[]b1={'a','c','A','L','0','d','k','a'};
        Arrays.sort(b1);
        System.out.println(Arrays.toString(b1));

        char[]b2={'b',97,'0','d',78,95};
        Arrays.sort(b2);
        System.out.println(Arrays.toString(b2));
        
        String[]c={"x","d","w","a","d"};
        Arrays.sort(c);
        System.out.println(Arrays.toString(c));

        String[]c1={"x","d","w","A","D","a","d"};
        Arrays.sort(c1);
        System.out.println(Arrays.toString(c1));
        
        
        
        }
    }
