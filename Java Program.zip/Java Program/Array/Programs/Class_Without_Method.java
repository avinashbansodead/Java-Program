class Class_Without_Method
{
	
		}