import java.util.*;
class String_Method_ToCharArray
{
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter your name");
		String a=sc.next();
		String c=new String("Hello");
		//System.out.println(a.toCharArray());
		char []b=a.toCharArray();
		System.out.println(b);
		System.out.println(b[0]);

		char []d=c.toCharArray();
		System.out.println(d);
System.out.println(Arrays.toString(b));
System.out.println(Arrays.toString(d));
	}
}