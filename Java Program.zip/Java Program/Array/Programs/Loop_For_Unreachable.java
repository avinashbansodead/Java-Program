class Loop_For_Unreachable
{
	public static void main(String[] args) {
		String a="Hii";
		
		for(int i=1; true;++i)
		{
			System.out.print(i+" ");
		}
		System.out.println(a);

		
	}
}