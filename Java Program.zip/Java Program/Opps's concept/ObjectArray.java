import java.util.*;
class ObjectArray
{
	public static void main(String[] args) {
		Object a[]={"Hello","byee"};
	Arrays.sort(a);
		System.out.println(Arrays.toString(a));

	}
	
} 