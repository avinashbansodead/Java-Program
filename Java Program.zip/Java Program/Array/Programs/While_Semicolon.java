class While_Semicolon
{
	public static void main(String[] args) {
		int i=1;
		System.out.println(i);
		while(i<=5);
		{
		System.out.println(i);
		++i;
		}
		System.out.println(i);
	}
}