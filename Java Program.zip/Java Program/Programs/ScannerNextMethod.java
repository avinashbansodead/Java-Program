import java.util.Scanner;
class ScannerNextMethod
{
	public static void main(String[] args) 
	{
		Scanner sc= new Scanner(System.in);
		String d=sc.nextLine();
		int a=sc.nextInt();
		String e=sc.nextLine();
		int b=sc.nextInt();
		int c=sc.nextInt();
		System.out.println(a+b+c);
		System.out.println(d);
		System.out.println(e);

	}
}