class Long_Datatype_Rule
{
	public static void main(String[] args) {
		long a=3125467894L;		
		System.out.println(a);
	}
}