import java.util.Scanner;
class InstaLogin
{
	public static void main(String[]args)
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("");
		System.out.println("*****Welcome To Instagram*****");
		String us1="Avinash";
		String pass1="Pass1234";
		int attempt=3;
		while(attempt>0)
		{
			System.out.print("User Name:  ");
			String us=sc.nextLine();
			System.out.print("Password: ");
			String pass=sc.nextLine();
			attempt--;
			if(us.equalsIgnoreCase(us1)&&pass.equals(pass1))
			{
				System.out.println(us1+"You are Sucessfully Login Instagram");
				login(us1);
				break;
			}
			else
			{
				if(attempt==0)
				{
					break;
				}
				else
				{
					System.out.println("Incorrect User Name & Password. Please Enter Correcet Password");
					System.out.println("Attempt Left"+attempt);
				}
			}


		}

	}
	public static void login(String us1)
	{
		for(; ;)
		{
		Scanner sc=new Scanner(System.in);
		System.out.println();
		System.out.println();
		System.out.println("Home Page ");
		System.out.println("Welcome" +us1);
		System.out.println("1: Chat");
		System.out.println("2: Search");
		System.out.println("3: Reels");
		System.out.println("4: Activity");
		System.out.println("5: Profile");
		System.out.println("6: Logout");
		System.out.println("=======*******==========");

		System.out.println("Enter an Option");
		int option=sc.nextInt();
		switch(option)
		{
			case 1:System.out.println("Chat Page Will Display");break;
			case 2:System.out.println("Search Page Will Display");break;
			case 3:System.out.println("Reels Page Will Display");break;
			case 4:System.out.println( "Activity Page Will Display");break;
			case 5:System.out.println("Profile Page Will Display");break;
			case 6:logout(us1);break;
			default:System.out.println("Enter Correct Option");break;
		}
	}
}
	public static void logout(String us1) 
	{
		System.out.println(us1+ "logout sucessfully");

	}
	
}