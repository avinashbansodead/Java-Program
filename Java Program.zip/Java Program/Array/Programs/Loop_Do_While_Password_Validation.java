import java.util.Scanner;
class Loop_Do_While_Password_Validation
{
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		
		
		int pass1=1234;
		int count=3;
		do
		{
			System.out.println("Enter the password");
			int pass=sc.nextInt();
			if(pass==pass1)
			{
				System.out.println("Login is Sucessfully");
				break;
			}
			else
			{
				System.out.println("Wrong password");
				System.out.println("Please enter the correct password");
				System.out.println("Your left chance: "+(count-1));
			}
			count--;
			}
			while(count!=0);
			if(count==0)
			{
				System.out.println("This system is not yours");
			}
		
	}
}