import java.util.*;
class Store_Factor
{
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the number");
		int num=sc.nextInt();
		int temp=num;
		int count=0;
		for(int i=1;i<num;i++)
			{
				if(num%i==0)
				{
					count++;
					
				}


			}


			int []b=new int[count];
			
				int count1=0;
					for(int i=1;i<temp;i++)
			       {
			       	
					
				
				
					if(temp%i==0)
				     {
					   b[count1]=i;
					   count1++;
					   
                     }
				  }
				  System.out.println(Arrays.toString(b));
				
					}
					
				}
	

			
		
	
