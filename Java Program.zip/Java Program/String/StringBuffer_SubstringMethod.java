class StringBuffer_SubstringMethod
{
	public static void main(String[] args) {
		StringBuffer sb=new StringBuffer("Hello");
sb.substring(0,3);
System.out.println(sb);
String a=sb.substring(0,3);
System.out.println(a);
	}
}