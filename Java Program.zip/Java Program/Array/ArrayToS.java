import java.util.Arrays;
class ArrayToS
{
	public static void main(String[] args) 
	{
		int[][]a={{50,60,70},{10,20,30}};
		System.out.println(Arrays.toString(a[0]));
	}
}
