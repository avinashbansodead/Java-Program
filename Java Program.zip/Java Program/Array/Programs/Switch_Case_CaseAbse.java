class Switch_Case_CaseAbse
{
	public static void main(String[] args) {
		int a=10;
		switch (a) {
			 System.out.println("Hii");
		}
	}
}