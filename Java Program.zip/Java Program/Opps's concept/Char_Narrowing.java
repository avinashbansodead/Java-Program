class Char_Narrowing
{
	public static void main(String[] args) {
		int a=122;
		char b=(char)a;
		System.out.println("char b="+b);
		//char c=a;
		//System.out.println(c);
	}
}
