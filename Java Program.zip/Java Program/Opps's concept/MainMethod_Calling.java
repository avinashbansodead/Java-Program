class MainMethod_Calling
{
	public static void main(String[] args) {
		System.out.println("Hello");
		String []a={};
		main(a);
	}
}