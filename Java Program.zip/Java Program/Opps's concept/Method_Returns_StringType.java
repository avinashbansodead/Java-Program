class Method_Returns_StringType
{String a="Hello";
	public static void main(String[] args) {
		Method_Returns_StringType b=new Method_Returns_StringType();
		
		String c=b.m1();
		System.out.println(c);
	}
	public String m1()
	{
		System.out.println("Hello");
		return a;
	}
}