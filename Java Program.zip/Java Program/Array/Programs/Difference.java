class Difference
{
	public static void main(String[] args) {
		System.out.print("Ram");
		System.out.print("-Lxman");
	}
	}
