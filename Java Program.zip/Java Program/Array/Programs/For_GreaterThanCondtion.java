class For_GreaterThanCondtion
{
	public static void main(String[] args) 
		{
			for (int i=5; i>=5;i--)
			{
				System.out.println(i);
			}
		}
}
