class Method_Return
{
	private int bal=2500;
	public static void main(String[] args) {
		Method_Return b= new Method_Return();
		double c=b.m1();
		System.out.println(c);
	}
	public double m1()
	{
return bal;
	}
}