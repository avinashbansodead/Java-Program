class Missing_Braces
{
	public static void main(String[] args) {
		System.out.println("Hii");
	
}