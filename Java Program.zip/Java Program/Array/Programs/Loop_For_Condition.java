class Loop_For_Condition
{
	public static void main(String[] args) {
		for(int a=1;;++a)
		{
			System.out.print(a+" ");
		}
	}
}