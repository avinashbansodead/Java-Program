class String_Concat_Method
{
	public static void main(String[] args) {
		String a="Bye";
		a+="bye";
		System.out.println(a);

		a+=10;
		System.out.println(a);

		a+=2.2;
		System.out.println(a);

		a+='a';
		System.out.println(a);

		a='a'+0+a;
		System.out.println(a);

		a=true+a;
		System.out.println(a);
	}
}