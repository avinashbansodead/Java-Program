class Byte_Max_Min_Value
{
	public static void main(String[] args) {
		System.out.println(Character.VALUE);
	}
}