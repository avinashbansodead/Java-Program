class Switch_Case_Char
{
	public static void main(String[] args) {
		
		switch(97)
		{
			case 98:System.out.println("Hii");
			break;
			case 'a':System.out.println("Hello");
			break;
			default:System.out.println("Byee");
			
		}
	}
}