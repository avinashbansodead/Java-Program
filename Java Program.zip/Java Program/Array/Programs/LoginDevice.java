import java.util.Scanner;
class LoginDevice
{
	public static void main(String[]args)
	{
		Scanner sc=new Scanner(System.in);
		String us1="Pass";
		String pass1="Pass123";
		int attempt=3;
		while(attempt>0)
		{
				System.out.print("Enter the User Name:");
				String us=sc.nextLine();
				System.out.print("Enter the Password");
				String pass=sc.nextLine();
				attempt--;
					if(us.equals(us1)&&pass.equals(pass1))
					{
						login();
						break;  
					}
					else
					{
					System.out.println("Incorrect Password Please Enter Correct Password");
						

					}
		}
	}
	public static void login()
	{
		System.out.println("System is sucefully login");
		System.out.println("Press Logout");
		logout();

	}
	public static void logout()
	{
		System.out.print("System is Sucefully Logout");
	}
}