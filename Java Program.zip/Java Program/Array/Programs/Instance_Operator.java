class Instance_Operator
{
	public static void main(String[] args) {
		Object p=new Instance_Operator();
		System.out.println(p instanceof Object);

	}
}