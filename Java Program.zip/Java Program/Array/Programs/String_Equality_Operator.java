import java.util.Scanner;
class String_Equality_Operator
{
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Any String");
		String a="Hello";
		String b=sc.next();
		System.out.println(a==b);
		System.out.println(a.equals(b));
System.out.println("Enter any character");
		char ch=sc.next().charAt(0);
		char d=48;

		System.out.println(d==ch);
int n='a';
System.out.println(n);


	}
}