class Cre1
{
	public static void main(String[] args)
	 {
		int [][]a={{10,20,30},{40,50}};
		System.out.println(a[0][0]);
		System.out.println(a[0][1]);
		System.out.println(a[0][2]);
		System.out.println(a[1][0]);
		System.out.println(a[1][1]);
	}
}