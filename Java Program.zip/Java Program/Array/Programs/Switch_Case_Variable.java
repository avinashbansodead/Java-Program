class Switch_Case_Variable
{
	public static void main(String[] args) {
		final int a=11;
		
		switch(12)
		{
			case 98:System.out.println("Hii");
			break;
			case 'a':System.out.println("Hello");
			break;
			case a+1:System.out.println("Hii");
			break;
			default:System.out.println("Byee");
			
		}
	}
}