class Maximum_Occurance
{
	public static void main(String[] args) 
	{
		int []a={10,20,10,30,40,10,20,10,30};
		int []temp=new int[a.length];
		int visited =-1;
		for(int i=0;i<a.length;i++)
		{
			int count=1;
			for(int j=i+1;j<a.length;j++)
			{
				if(a[i]==a[j])
				{
					count++;
					temp[j]=visited;
				}
			}
			if(temp[i]!=visited)
			{
				temp[i]=count;
			}

		}
		for (int s=0;s<temp.length;s++)
		{
			if(temp[s]!=visited&& temp[s]>1)
			{
				System.out.println(a[s]+" is duplicate number and it ocuurance is " +temp[s]);
			}
		} 
	}
}
