class StringConstructor_StringBuilder
{
	public static void main(String[] args) {
		StringBuilder sb=new StringBuilder("Hello");
		String sb1=sb.toString();
		String s=new String(sb1);
		System.out.println(s==sb);
		System.out.println(sb1==s);
		System.out.println(s);
	}
}