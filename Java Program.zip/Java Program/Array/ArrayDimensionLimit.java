class ArrayDimensionLimit
{
	public static void main(String[] args) {
		int[][][][][]a= new int[2147483647][2147483647][2147483647][2147483647][2147483647];
	}
}