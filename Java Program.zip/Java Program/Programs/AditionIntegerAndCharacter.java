class AditionIntegerAndCharacter
{
	public static void main(String[] args) {
		int a='a';
		char b=10;
		int c=a/b;
		int d=b;
		System.out.println(c);
		System.out.println(d);
	}
}