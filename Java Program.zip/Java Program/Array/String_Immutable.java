class String_Immutable
{
	public static void main(String[] args) {
		String a="Hello";
		a="byee";
	}
}