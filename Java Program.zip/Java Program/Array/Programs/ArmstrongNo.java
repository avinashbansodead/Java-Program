import java.util.Scanner;
class ArmstrongNo
{
	public static void main(String[]args)
	{
		Scanner sc=new Scanner(System.in);
		System.out.print("Enter the Number");
		float num=sc.nextFloat();
		float temp=num;
		double sum=0;
		double count=0;
		while(num!=0)
		{
		count=num/10;
	count++;
		while(num!=0)
		{ 
		
		   float rem=num%10;
		  double b=Math.pow(rem,count);
			sum=sum+b;
			num/=10;
			
		}
	}
		if(temp==sum)
		{
			System.out.print(temp+"It is an Armstrong Number");

		}
		else
		{
			System.out.print( temp+"It is not an Armstrong Number");
		}
		
	}

	}