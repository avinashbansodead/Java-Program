import java.util.*;
class Store_Name
{
	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter your name");
	  String name=sc.nextLine();
		char[]a=new char[name.length()];
		
		for(int i=0;i<name.length();i++)
		{
			a[i]=name.charAt(i);
		}
		System.out.println(Arrays.toString(a));
		byte[]b={'a'+0,'b'+0,' ',1};
		System.out.println(Arrays.toString(b));
		char x='a'+1;
		System.out.println(x);
		char p=97;
		char q=p;
System.out.println(q);
char f=1;
System.out.println(f);
		
	}
}