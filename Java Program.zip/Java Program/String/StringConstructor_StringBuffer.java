class StringConstructor_StringBuffer
{
	public static void main(String[] args) {
		StringBuffer sb=new StringBuffer("Hello");
		String sb1=sb.toString();

		String s=new String(sb1);
		//System.out.println(s==sb);
		System.out.println(sb1==s);
		System.out.println(s);
		
	}
}