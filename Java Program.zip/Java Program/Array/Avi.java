import java.util.ArrayList;
import java.util.List;
import java.util.Collection;
public class Avi
{
    public static void main(String[] args)
    {
    List l=new ArrayList()
    l.add(10);
    system.out.println(l)
}
}