class Clone_Method implements Cloneable
{
	int i=10;
	int j=20;
	public static void main(String[] args) throws CloneNotSupportedException
	{
		Clone_Method m1=new Clone_Method();
		Clone_Method m2=(Clone_Method)m1.clone();
		m2.i=888;
		m2.j=999;
		System.out.println(m1.i+" "+m1.j);
		System.out.println(m2.i+" "+m2.j);

	}
}