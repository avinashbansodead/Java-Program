import java.util.Arrays;
  
class Arrays_SortMethod_WithArgument
 {
    public static void main(String args[])
    {
        int[] a = { 5,2,1,4,3,6,7,8 };
        Arrays.sort(a,0,5);
         System.out.println(Arrays.toString(a));

        char[]b={'a','b','d','e','c'};
        Arrays.sort(b,2,5);
        System.out.println(Arrays.toString(b));

        
        
        String[]c={"x","v","y","u","z"};
        Arrays.sort(c,0,4);
        System.out.println(Arrays.toString(c));

        
        
        
        
        }
    }
