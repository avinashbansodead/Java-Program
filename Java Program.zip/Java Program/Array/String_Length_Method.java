import java.util.Scanner;
class String_Length_Method
{
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter your name");
		String a=sc.nextLine();
		System.out.println(a.length());
		String b="Avinash Bansode";
		System.out.println(b.length());
	
	}
}