class For_False_Condition
{
	public static void main(String[] args) {
		int a=10;
		int b=20;
		for(int i=1; a>b;i++)
		{
			System.out.println(i);
		}
		System.out.println("Byee");
	}
}