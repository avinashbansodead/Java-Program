class VariableArgument
{
	public static void main(String[] args) {
		m1(10,20,30);
	}
	public static void m1(int...a) {
		System.out.println(a[0]);
		
	}
}