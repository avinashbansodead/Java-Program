
import java.util.Scanner;
class Char_Ascill_Value
{
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the name");
		char ch=sc.nextLine().charAt(0);

		if(ch>=65&&ch<=90||ch>=97&&ch<=122)		
		{
			System.out.println("It is an aplphabet");
			if(ch>=65&&ch<=90)
				System.out.println("Ascii value:"+(ch+0));
		}
		
	}
}