class Switch_Case_With_FinalVariable
{
	public static void main(String[] args) {
		int a=10;
		final int b=20;
		switch(b)
		{
			case 9+1:System.out.println("Hii");
			break;
			case b:System.out.println("Hello");
			break;
			default:System.out.println("Byee");
			
		}
	}
}