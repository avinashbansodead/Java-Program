class StaticProgrm
{
	public static void main(String[] args)
	 {
		int a=10;
		String a="Raju";
		System.out.println(a);

	}
}