class For_ConditionFalseWithoutFinalVariable
{
public static void main(String[] args) {
	int a=10;
	int b=20;
	for(int i=1;false;i++)
	{
		System.out.println(i);
	}
}
}