class Switch_Case_Byte_RangeCross
{
	public static void main(String[] args) {
		byte a=127;
		switch(a+2)
		{
			case 9:System.out.println("Hii");
			break;
			case 129:System.out.println("Hello");
			break;
			default:System.out.println("Byee");
			
		}
	}
}