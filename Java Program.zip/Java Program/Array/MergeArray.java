import java.util.*;
class MergeArray
{
public static void main(String[] args)
 {
 	int[][]a={{10,20,30,40},{50,60,70,80}};
 	int[]b=new int [a[0].length+a[1].length];
 	int count=0;
 	for(int i=0;i<a.length;i++)
 	{
 		for(int j=0;j<a[i].length;j++)
 		{
 	
 		b[count]=a[i][j];
 		count++;
 	}
 }
	System.out.print(Arrays.toString(b));
}
}