import java.util.Scanner;
class NeonNo
{
	public static void main(String[]args)
	{
		Scanner sc=new Scanner(System.in);
		System.out.print("Enter the Number");
		int num=sc.nextInt();
		int temp=num;
		int sq=num*num;
		int sum=0;
		while(sq!=0)
		{
			int rem=sq%10;
			sum=sum+rem;
			sq=sq/10;
		}
			if(num==sum)
			{
				System.out.print(num+"It is Neon Number");

			}

			else
			{
			System.out.print(num+"It is not a Neon Number");
		    }
		
	}
}