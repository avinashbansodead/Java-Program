class String_Synchronization
{
	public static void main(String[] args) {
		StringBuffer sb=new StringBuffer("Apple");
		sb.append("Boy");
		System.out.println(sb);
		sb.append("Cat");
		System.out.println(sb);
		
		sb.append("Dog");
		System.out.println(sb);

		sb.append("Elephant");
		System.out.println(sb);

		sb.append("Food");
		System.out.println(sb);

		sb.append("Girl");
		System.out.println(sb);

		sb.append("Hen");
		System.out.println(sb);

		sb.append("Ink");
		System.out.println(sb);

		sb.append("Joker");
		System.out.println(sb);

		sb.append("Ko");
		System.out.println(sb);

		sb.append("Lemon");
		System.out.println(sb);

		sb.append("Monkey");
		System.out.println(sb);

		sb.append("Night");
		System.out.println(sb);

		sb.append("Operation");
		System.out.println(sb);

		sb.append("Question");
		System.out.println(sb);

		sb.append("Rose");
		System.out.println(sb);

		sb.append("Tiger");
		System.out.println(sb);

		sb.append("Umberalla");
		System.out.println(sb);

		sb.append("Vanilla");
		System.out.println(sb);

		sb.append("Wait");
		System.out.println(sb);

		sb.append("X-ray");
		System.out.println(sb);

		sb.append("Yet");
		System.out.println(sb);

		sb.append("Zerox");
		System.out.println(sb);


	}
}