class StringConstructor_Variable
{
	public static void main(String[] args) {
		String a="Welcome to java";
		String b=new String(a);
		System.out.println(b);
		System.out.println(a==b);
	}
}