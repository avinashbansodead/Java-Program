class Constructor_Chain
{
	public static void main(String[] args) {
		Constructor_Chain c=new Constructor_Chain();

	}
	Constructor_Chain()
	{
		super();
		System.out.println("Hello");
	}
}