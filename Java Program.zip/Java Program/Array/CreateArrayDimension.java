import java.util.*;
class CreateArrayDimension
{
public static void main(String[] args) {
	int[][][]a=new int[3][][];
	System.out.println(a.length);
	a[0]=new int[2][];
	System.out.println(a[0].length);

}
}