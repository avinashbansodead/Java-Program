class Loop_Do_While_FinalCondition
{
	public static void main(String[] args) {
		 final int i=1;
		  final int j=5;
		 
		do
		{
			System.out.println(i);
			

		}
		while(i<=j);
		System.out.println("Hello");
	}
}