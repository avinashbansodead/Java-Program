class Change_Method_Name
{
	public static void main(String[] args) {
		
	}
}