class Reassigning_To_Static
{
	static int a=20;
	public static void main(String[] args) {
		a=30;
		System.out.println(Reassigning_To_Static.a);
		m1();
	}
	default static void m1()
	{
		System.out.println("Heloo");
	}
}