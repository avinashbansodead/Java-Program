import java.util.*;
class Char_Array_ToString
{
	public static void main(String[] args) {
		char[]a={97,98,99};
		System.out.print(Arrays.toString(a));
	}
}