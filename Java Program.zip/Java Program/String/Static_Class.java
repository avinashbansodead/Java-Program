static class Static_Class
{
	int a=20;
	public static void main(String[] args) {
		Static_Class.a();
System.out.println(a);
	
	}
}