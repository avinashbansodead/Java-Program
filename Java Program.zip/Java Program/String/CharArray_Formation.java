import java.util.*;
class CharArray_Formation
{
	public static void main(String[] args) {
		String name="ABCD";
		char[]a=new char[name.length()];
		//int[]a=new int[name.length()];
		for(int i=0;i<name.length();i++)
		{
			//a[i]=name.charAt(i)+0;
			a[i]=name.charAt(i);

			a[i]+=32;
		}
		System.out.println(Arrays.toString(a));
		
	}
}