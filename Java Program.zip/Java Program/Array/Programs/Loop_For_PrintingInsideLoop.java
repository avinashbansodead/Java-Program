class Loop_For_PrintingInsideLoop
{
	public static void main(String[] args) {
		int i=1;
		
		for(System.out.println("Hello"); i<5;++i)
		{
			System.out.print(i+" ");
		}
		
		
	}
}