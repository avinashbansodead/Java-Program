class String_Method_Append
{
	public static void main(String[] args) {
		StringBuffer a=new StringBuffer("Hello");
		

		char []b={'b','y','e','e'};
		a.append(b);
		System.out.println(a);

		Object m1=1;
		a.append(m1);
		System.out.println(a);
		
		StringBuffer sb=new StringBuffer("Byee");
		a.append(sb);
		System.out.println(a);

	}
}