class String_Method_Substring
{
public static void main(String[] args) {
	String a="javaiseasy";
	System.out.println(a);
	System.out.println(a.substring(2));
	System.out.println(a.substring(2,8));
	System.out.println(a.substring(2,10));
	System.out.println(a.substring(2));
	System.out.println(a.substring(2,2));
	System.out.println(a.substring(2,0));
	
}
}