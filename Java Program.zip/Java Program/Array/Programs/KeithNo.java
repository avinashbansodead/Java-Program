import java.util.Scanner;
class KeithNo
{
	public static void main(String[]args)
	{
Scanner sc=new Scanner(System.in);
System.out.print("Enter the Number");
int num=sc.nextInt();

int length=0;
int temp=num;


while(num!=0)
{
	num/=10;
	length++;
	

}
System.out.println(length);
if (length==2)
{
	
	
	int add=0;


	int first=temp/10;

	int second=temp%10;

	
		while(add<temp)

	{
	add=first+second;
	
	first=second;
	
	second=add;

}

	if(add==temp)
	{
		System.out.println(temp+" is a keith number");
	}
	else 
	{
		System.out.println(temp+" is not a keith number");
	}
	


}





	
else if(length==3)
{
	int add=0;
	int first=temp/100;
	int second=(temp/10)%10;
	int third=temp%10;
	while(add<temp)
	{
		add=first+second+third;
		first=second;
		second=third;
		third=add;

	}
		if(add==temp)
		{
			System.out.println(temp+" is a keith number");

		}
		else
       {
	System.out.println(temp+"It is not a keith number");
	
       }
		

	

}




}
}

