class Non_Static_Variable

{
	int a=20;
	public static void main(String[] args) {
		Non_Static_Variable a1=new Non_Static_Variable();
		System.out.println("20:"+ a1.a);
		a1.a=30;
		System.out.println("30:"+a1.a);
		a1.m1();
	}
	public void m1()
	{
		Non_Static_Variable a2=new Non_Static_Variable();
		System.out.println("20:" +a2.a);
		a=100;
		System.out.println("100:" +a);
		this.m3();
		a2.m4();
	}
	public void m3()
	{
		System.out.println("100:" +a);
	}
	public void m4()
	{
		System.out.println("20:" +a);
	}
}