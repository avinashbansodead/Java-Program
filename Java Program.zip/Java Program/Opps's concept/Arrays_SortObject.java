import java.util.Arrays;
class Arrays_SortObject
{
	public static void main(String[] args) {
		int []a={1,2,2};
		System.out.println(Arrays.sort(a));


	}
}