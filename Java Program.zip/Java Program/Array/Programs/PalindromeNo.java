import java.util.Scanner;
class PalindromeNo
{
	public static void main(String[]args)
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the Number");
		int num=sc.nextInt();
		int b=0;
		int temp=num;
		while(num!=0)
		{
			int rem=num%10;
			b=b*10+rem;
			num/=10;
			
		}
		if(b==temp)
			{
				System.out.print(temp+" is a palindrome number");
			}
			else
			{
				System.out.println(temp+" is not a palindrome number");
			}

	}
}