class GlobalVarible_AssignValue
{
	static int a=20;
	public static void main(String[] args) {
		int a=30;
		System.out.println(a);
		System.out.println(GlobalVarible_AssignValue.a);
	}
}