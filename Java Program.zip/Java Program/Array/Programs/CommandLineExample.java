import java.util.*;
class CommandLineExample
{
	public static void main(String[] args) {
		for(int i=0;i<args.length;i++)
		{
			System.out.println(args[i]);
		}
		 String i=args[0]+args[1];
		System.out.println(i);
		System.out.println(Arrays.toString(args));
	}
}